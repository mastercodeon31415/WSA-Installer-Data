# 5037连接超时

本应用采用的通信方式简略如下:

```
App -> Adb Server(127.0.0.1:5037) -> DeviceA Wsa(127.0.0.1:58526)
                                  -> DeviceB (192.168.1.222:52544)
                                  -> DeviceC (Usb)

5037是Adb Server的默认端口                                 
``` 
本应用使用UWP开发,系统默认限制UWP程序对本地回环网络的访问

正常情况下应用会自动尝试解除这个限制,但是如果出现此问题,需要尝试手动解除


## 解除本地回环限制


- 第一种方法: 在cmd中执行 (注意不是powershell)
```
 CheckNetIsolation.exe LoopbackExempt -a -n=7061touchwp.AowTools_m9vp3t2f55f5t
``` 
- 第二种方法: 使用gui工具 
```
 https://docs.telerik.com/fiddler/configure-fiddler/tasks/configurefiddlerforwin8
```

# ADB无法连接
## 使用外部adb.exe   
下载最新的adb,然后在设置中选择adb.exe

## 手动运行
重新打开 adb server,在cmd中执行

```
adb.exe kill-server 
adb.exe start-server 
```

# WSA无法连接

## WSA开发模式
在WSA设置中检查是否打开开发模式

## 手动连接
```
adb disconnect 127.0.0.1:58526
adb connect 127.0.0.1:58526
```
## 检查设备列表
```
adb devices -l
```

# WSA无法安装
在WSA设置中关闭 阻止恶意软件安装

# 无法卸载
因为后台启动了adb server,如果无法卸载,需要手动关闭adb server,然后即可卸载

```
taskkill /IM adb.exe
```