# 127.0.0.1:5037 Connection timed out

This application communicates with the device as follows:

```
App -> Adb Server(127.0.0.1:5037) -> DeviceA Wsa(127.0.0.1:58526)
                                  -> DeviceB (192.168.1.222:52544)
                                  -> DeviceC (Usb)

5037 is the default port of Adb Server                                      
``` 
This application is a UWP application, the system by default restricts the UWP application to access the local loopback network

Usually application will automatically try to remove this restriction, but if this happens you will need to try to remove it manually


## Remove local loopback restrictions

- First way: run in cmd (note: not powershell)
```
 CheckNetIsolation.exe LoopbackExempt -a -n=7061touchwp.AowTools_m9vp3t2f55f5t
``` 
- Second way: Use gui tool 
```
 https://docs.telerik.com/fiddler/configure-fiddler/tasks/configurefiddlerforwin8
```

# ADB cannot be connected
## Use external adb.exe   
Download the latest ADB and in the settings select the adb.exe

## Run ADB manually
restart adb server, open cmd and run 

```
adb.exe kill-server 
adb.exe start-server 
```

# WSA cannot be connected

## WSA Development Model
In the WSA settings, check whether the development mode is enabled

## Manual connection
```
adb disconnect 127.0.0.1:58526
adb connect 127.0.0.1:58526
```
## Check  devices list
```
adb devices -l
```

# WSA cannot be installed
Open WSA settings and disable block malware installation


# Uninstall Failed
adb server is running in the background, need to manually close the adb server, then uninstall

```
taskkill /IM adb.exe
```